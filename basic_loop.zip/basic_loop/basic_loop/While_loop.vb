﻿Public Class frmWhile
    Private Sub btnRepeat_Click(sender As Object, e As EventArgs) Handles btnRepeat.Click
        Dim intnum As Integer = 3
        Do While intnum < 25
            intnum += 10
            lstDisplay.Items.Add("I just added 10 to the number")
        Loop
    End Sub
End Class
